# Sampling
from imblearn.under_sampling import RandomUnderSampler
from imblearn.pipeline import make_pipeline as make_imb_pipeline

# Utils
from sklearn.pipeline import make_pipeline
from sklearn.base import clone

# Models
from sklearn.ensemble import VotingClassifier
from sklearn.tree import DecisionTreeClassifier

class ResampledEnsemble:
    
    def __init__(self, base_estimator=DecisionTreeClassifier(), n_estimators=100, 
                 max_depth=None, max_features=None, min_samples_split=2, min_samples_leaf=1):
        
        self._estimator_type = "classifier"
        self.base_estimator = base_estimator
        self.n_estimators = n_estimators
        self.max_depth = max_depth
        self.max_features = max_features
        self.min_samples_split = min_samples_split
        self.min_samples_leaf = min_samples_leaf
        self.estimators = self._generate_estimators()
        self.estimator = VotingClassifier(self.estimators, voting="soft")
    
    def _generate_estimators(self):
        estimators = []
        for i in range(self.n_estimators):
            est = clone(self.base_estimator)
            est.random_state = i
            est.max_depth = self.max_depth
            est.max_features = self.max_features
            est.min_samples_split = self.min_samples_split
            est.min_samples_leaf = self.min_samples_leaf
            pipe = make_imb_pipeline(
                RandomUnderSampler(random_state=i, replacement=True),
                est
            )
            estimators.append((f"est_{i}", pipe))
        return estimators
    
    def set_params(self, **params):
        if not params:
            # Simple optimization to gain speed (inspect is slow)
            return self

        for key, value in params.items():
            if hasattr(self, key):
                setattr(self, key, value)
            else:
                self.kwargs[key] = value
                
        self.estimators = self._generate_estimators()
        self.estimator = VotingClassifier(self.estimators, voting="soft")
        return self
        
    def fit(self, X, y, sample_weight=None):
        return self.estimator.fit(X, y, sample_weight)
    
    def predict(self, X):
        return self.estimator.predict(X)
        